# CineNote — Movie Information Portal

A frontend mini-project aligned with the Movie Information Portal SRS (Web Technology–I).

## Run
Open `index.html` in a modern browser. Internet connection is needed for Bootstrap, jQuery, Google Fonts, poster images and embedded trailers.

## Pages
- Home: featured movies and genre shortcuts
- Movies: dynamic catalogue with keyword search, genre/language/year/rating filters and sorting
- Movie details: synopsis, cast, director, language, duration, rating and trailer
- Favorites: add/remove saved movies
- Reviews: submit and dynamically view reviews (client-side validation)
- Contact: feedback form with client-side validation

## Implementation
HTML5, CSS3, JavaScript arrays/objects, DOM, jQuery, Bootstrap 5 and LocalStorage. No backend/database is required. Favorites and reviews are stored in the browser's LocalStorage. Includes 15 movie records.
